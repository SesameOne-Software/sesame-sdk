#ifndef FEATURES_MOVEMENT_H
#define FEATURES_MOVEMENT_H

#include "include/ses.h"

void features_movement_run ( usercmd* cmd );

#endif // !FEATURES_MOVEMENT_H