#ifndef RESOURCES_H
#define RESOURCES_H

extern const unsigned int resources_noto_compressed_size;
extern const unsigned int resources_noto_compressed_data [ 244712 / 4 ];

//extern const unsigned int resources_noto_cjk_compressed_size;
//extern const unsigned int resources_noto_cjk_compressed_data [ 13541660 / 4 ];
//
//extern const unsigned int resources_noto_emoji_compressed_size;
//extern const unsigned int resources_noto_emoji_compressed_data [ 355368 / 4 ];

extern const unsigned int resources_logo_size;
extern const unsigned int resources_logo_data[51740 / 4];

#endif // !RESOURCES_H