# sesame-sdk
Newer version of my CSGO SDK (written in pure C) used for the "Sesame" project.
