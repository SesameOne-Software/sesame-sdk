#include "include/hooks/hooks.h"

void __fastcall hooks_notify_on_layer_change_cycle ( REG, animlayer* layer, float new_cycle ) {

}