#include "include/hooks/hooks.h"

bool __fastcall hooks_should_skip_anim_frame ( REG ) {
	return false;
}