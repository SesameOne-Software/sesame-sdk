#include "include/hooks/hooks.h"

subhook_t hooks_subhooks [ subhook_max ];