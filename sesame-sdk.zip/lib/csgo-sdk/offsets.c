#include "offsets.h"

cs_offsets_s cs_offsets;