#ifndef SDK_QUAT_H
#define SDK_QUAT_H

typedef struct {
	float x, y, z, w;
} quat;

#endif // !SDK_QUAT_H